project_fadex
=============

A Symfony project created on April 17, 2017, 9:58 am.
## Web server setup
### Apache directives configuration
    ServerName fadex.demo.com
    DocumentRoot /var/www/html/project_fadex/web
    <Directory /var/www/html/project_fadex/web>
            Options -Indexes +FollowSymLinks +MultiViews
            AllowOverride All
            Require all granted
    </Directory>
    ErrorLog /var/log/apache2/project_fadex_error.log

### Local DNS settings (host file)
    127.0.1.1       fadex.demo.com