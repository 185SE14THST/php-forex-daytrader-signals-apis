<?php

/* default/index.html.twig */
class __TwigTemplate_5ca8a686b7e9a3c83e7afb0a877514bd10cdbf5e86970abd82cf580add204dbb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1d5f08a1f4fdd6d121b04b1e69aacc2178db66f98e7b165b4c7d8bc9e3763c16 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1d5f08a1f4fdd6d121b04b1e69aacc2178db66f98e7b165b4c7d8bc9e3763c16->enter($__internal_1d5f08a1f4fdd6d121b04b1e69aacc2178db66f98e7b165b4c7d8bc9e3763c16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $__internal_7eb6762d18bebef3efcb1108337b0e78ed5e175546cb597897ba4facc948efe7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7eb6762d18bebef3efcb1108337b0e78ed5e175546cb597897ba4facc948efe7->enter($__internal_7eb6762d18bebef3efcb1108337b0e78ed5e175546cb597897ba4facc948efe7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1d5f08a1f4fdd6d121b04b1e69aacc2178db66f98e7b165b4c7d8bc9e3763c16->leave($__internal_1d5f08a1f4fdd6d121b04b1e69aacc2178db66f98e7b165b4c7d8bc9e3763c16_prof);

        
        $__internal_7eb6762d18bebef3efcb1108337b0e78ed5e175546cb597897ba4facc948efe7->leave($__internal_7eb6762d18bebef3efcb1108337b0e78ed5e175546cb597897ba4facc948efe7_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_960f3030995ca15e75d53177d80ab7c0c159302efdf7d37af75643d9cf4910c3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_960f3030995ca15e75d53177d80ab7c0c159302efdf7d37af75643d9cf4910c3->enter($__internal_960f3030995ca15e75d53177d80ab7c0c159302efdf7d37af75643d9cf4910c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b7271349da49fca82d3e7ec4abdd75c4521471772cf4ea5a711a3197b823499a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7271349da49fca82d3e7ec4abdd75c4521471772cf4ea5a711a3197b823499a->enter($__internal_b7271349da49fca82d3e7ec4abdd75c4521471772cf4ea5a711a3197b823499a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <section class=\"jumbotron text-center demo\">
        <div class=\"container\">
            <h1 class=\"jumbotron-heading\">Album example</h1>
            <p class=\"lead text-muted\">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don't simply skip over it entirely.</p>
            <p>
                <a href=\"#\" class=\"btn btn-primary\">Main call to action</a>
                <a href=\"#\" class=\"btn btn-secondary\">Secondary action</a>
            </p>
        </div>
    </section>

    <div class=\"album text-muted\">
        <div class=\"container\">

            ...

        </div>
    </div>
";
        
        $__internal_b7271349da49fca82d3e7ec4abdd75c4521471772cf4ea5a711a3197b823499a->leave($__internal_b7271349da49fca82d3e7ec4abdd75c4521471772cf4ea5a711a3197b823499a_prof);

        
        $__internal_960f3030995ca15e75d53177d80ab7c0c159302efdf7d37af75643d9cf4910c3->leave($__internal_960f3030995ca15e75d53177d80ab7c0c159302efdf7d37af75643d9cf4910c3_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <section class=\"jumbotron text-center demo\">
        <div class=\"container\">
            <h1 class=\"jumbotron-heading\">Album example</h1>
            <p class=\"lead text-muted\">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don't simply skip over it entirely.</p>
            <p>
                <a href=\"#\" class=\"btn btn-primary\">Main call to action</a>
                <a href=\"#\" class=\"btn btn-secondary\">Secondary action</a>
            </p>
        </div>
    </section>

    <div class=\"album text-muted\">
        <div class=\"container\">

            ...

        </div>
    </div>
{% endblock %}
", "default/index.html.twig", "/var/www/html/project_fadex/app/Resources/views/default/index.html.twig");
    }
}
