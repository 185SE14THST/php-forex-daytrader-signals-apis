<?php

/* default/index.html.twig */
class __TwigTemplate_ce165f308c5e80888e5ac8e181fbc15201158960b41a0fccd1985d644d21924b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_92fea7fd69426733891837150a9bd6e8dc9a63e49c417a9d3c3b560a3f35812c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_92fea7fd69426733891837150a9bd6e8dc9a63e49c417a9d3c3b560a3f35812c->enter($__internal_92fea7fd69426733891837150a9bd6e8dc9a63e49c417a9d3c3b560a3f35812c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $__internal_bba26efae8672a9806503b2d44ba93874773546c722e7f320ace659861bce0e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bba26efae8672a9806503b2d44ba93874773546c722e7f320ace659861bce0e5->enter($__internal_bba26efae8672a9806503b2d44ba93874773546c722e7f320ace659861bce0e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_92fea7fd69426733891837150a9bd6e8dc9a63e49c417a9d3c3b560a3f35812c->leave($__internal_92fea7fd69426733891837150a9bd6e8dc9a63e49c417a9d3c3b560a3f35812c_prof);

        
        $__internal_bba26efae8672a9806503b2d44ba93874773546c722e7f320ace659861bce0e5->leave($__internal_bba26efae8672a9806503b2d44ba93874773546c722e7f320ace659861bce0e5_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_70a118aaa7b0302745f2108d6eba9c029cc9d8bea1680af1582ded5c794caf28 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70a118aaa7b0302745f2108d6eba9c029cc9d8bea1680af1582ded5c794caf28->enter($__internal_70a118aaa7b0302745f2108d6eba9c029cc9d8bea1680af1582ded5c794caf28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b8d66924ad223b75dae2d902042244e925243db2b794723ee4f2044977c3c464 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8d66924ad223b75dae2d902042244e925243db2b794723ee4f2044977c3c464->enter($__internal_b8d66924ad223b75dae2d902042244e925243db2b794723ee4f2044977c3c464_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <section class=\"jumbotron text-center demo\">
        <div class=\"container\">
            <h1 class=\"jumbotron-heading demotitle\">Currency Spotlight</h1>
            <p class=\"lead\">Binary options are limited-risk contracts based on a simple yes/no question about the market's price action. Use post signals for deeper insight.</p>
            <div class=\"form-group form-inline row\">
                <div class=\"col-12\">
                    <input class=\"form-control\" type=\"search\" value=\"USDGBP\" id=\"example-search-input\">
                    <a href=\"/\" class=\"btn btn-primary\">Quick Analysis</a>

                </div>
            </div>

            <ul class=\"nav justify-content-center\">
                <li class=\"nav-item\">
                    <a class=\"nav-link active demostats\" href=\"#\"><i class=\"fa fa-line-chart fa-2x\"></i> <h1>";
        // line 18
        echo twig_escape_filter($this->env, ($context["test"] ?? $this->getContext($context, "test")), "html", null, true);
        echo "</h1></a>
                </li>
            </ul>
            <p>

            </p>
        </div>
    </section>

    <div class=\"album text-muted\">
        <div class=\"container\">

            <div class=\"row\">
                <div class=\"card\">
                    <p><strong>USD/EUR</strong></p>
                    <div id=\"chart_diva\" style=\"width: 356px; height: 280px;\"></div>
                    <p class=\"card-text\"><i class=\"fa fa-newspaper-o fa-1x\"></i>&nbsp;Daily Fx: The British Pound against the US Dollar is one of the oldest currency pairings in the world. The pair is often called 'The Cable', as the first transatlantic communication cable run across the floor of the Atlantic.</p>
                </div>
                <div class=\"card\">
                    <p><strong>USD/GBP</strong></p>
                    <div id=\"chart_divb\" style=\"width: 356px; height: 280px;\"></div>
                    <p class=\"card-text\"><i class=\"fa fa-newspaper-o fa-1x\"></i>&nbsp;Daily Fx: The British Pound against the US Dollar is one of the oldest currency pairings in the world. The pair is often called 'The Cable', as the first transatlantic communication cable run across the floor of the Atlantic.</p>
                </div>
                <div class=\"card\">
                    <p><strong>USD/JPY</strong></p>
                    <div id=\"chart_divc\" style=\"width: 356px; height: 280px;\"></div>
                    <p class=\"card-text\"><i class=\"fa fa-newspaper-o fa-1x\"></i>&nbsp;Daily Fx: The British Pound against the US Dollar is one of the oldest currency pairings in the world. The pair is often called 'The Cable', as the first transatlantic communication cable run across the floor of the Atlantic.</p>
                </div>
            </div>

        </div>
    </div>
";
        
        $__internal_b8d66924ad223b75dae2d902042244e925243db2b794723ee4f2044977c3c464->leave($__internal_b8d66924ad223b75dae2d902042244e925243db2b794723ee4f2044977c3c464_prof);

        
        $__internal_70a118aaa7b0302745f2108d6eba9c029cc9d8bea1680af1582ded5c794caf28->leave($__internal_70a118aaa7b0302745f2108d6eba9c029cc9d8bea1680af1582ded5c794caf28_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 18,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <section class=\"jumbotron text-center demo\">
        <div class=\"container\">
            <h1 class=\"jumbotron-heading demotitle\">Currency Spotlight</h1>
            <p class=\"lead\">Binary options are limited-risk contracts based on a simple yes/no question about the market's price action. Use post signals for deeper insight.</p>
            <div class=\"form-group form-inline row\">
                <div class=\"col-12\">
                    <input class=\"form-control\" type=\"search\" value=\"USDGBP\" id=\"example-search-input\">
                    <a href=\"/\" class=\"btn btn-primary\">Quick Analysis</a>

                </div>
            </div>

            <ul class=\"nav justify-content-center\">
                <li class=\"nav-item\">
                    <a class=\"nav-link active demostats\" href=\"#\"><i class=\"fa fa-line-chart fa-2x\"></i> <h1>{{ test }}</h1></a>
                </li>
            </ul>
            <p>

            </p>
        </div>
    </section>

    <div class=\"album text-muted\">
        <div class=\"container\">

            <div class=\"row\">
                <div class=\"card\">
                    <p><strong>USD/EUR</strong></p>
                    <div id=\"chart_diva\" style=\"width: 356px; height: 280px;\"></div>
                    <p class=\"card-text\"><i class=\"fa fa-newspaper-o fa-1x\"></i>&nbsp;Daily Fx: The British Pound against the US Dollar is one of the oldest currency pairings in the world. The pair is often called 'The Cable', as the first transatlantic communication cable run across the floor of the Atlantic.</p>
                </div>
                <div class=\"card\">
                    <p><strong>USD/GBP</strong></p>
                    <div id=\"chart_divb\" style=\"width: 356px; height: 280px;\"></div>
                    <p class=\"card-text\"><i class=\"fa fa-newspaper-o fa-1x\"></i>&nbsp;Daily Fx: The British Pound against the US Dollar is one of the oldest currency pairings in the world. The pair is often called 'The Cable', as the first transatlantic communication cable run across the floor of the Atlantic.</p>
                </div>
                <div class=\"card\">
                    <p><strong>USD/JPY</strong></p>
                    <div id=\"chart_divc\" style=\"width: 356px; height: 280px;\"></div>
                    <p class=\"card-text\"><i class=\"fa fa-newspaper-o fa-1x\"></i>&nbsp;Daily Fx: The British Pound against the US Dollar is one of the oldest currency pairings in the world. The pair is often called 'The Cable', as the first transatlantic communication cable run across the floor of the Atlantic.</p>
                </div>
            </div>

        </div>
    </div>
{% endblock %}", "default/index.html.twig", "/var/www/html/project_fadex/app/Resources/views/default/index.html.twig");
    }
}
