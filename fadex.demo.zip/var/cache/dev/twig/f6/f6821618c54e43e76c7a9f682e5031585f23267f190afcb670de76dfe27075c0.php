<?php

/* base.html.twig */
class __TwigTemplate_c079c483fda7a48245ce7813ce27ee2c7542bb36c5db428af0c4b36395d37d53 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_37681746a841c85517b221b140e12c55d3b168ccc541320bf82efdc4fea282c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_37681746a841c85517b221b140e12c55d3b168ccc541320bf82efdc4fea282c4->enter($__internal_37681746a841c85517b221b140e12c55d3b168ccc541320bf82efdc4fea282c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_f2475e44ec6a9bbba507dea6407042987138c83629586ae1efef90ba84c9ecba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2475e44ec6a9bbba507dea6407042987138c83629586ae1efef90ba84c9ecba->enter($__internal_f2475e44ec6a9bbba507dea6407042987138c83629586ae1efef90ba84c9ecba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"http://v4-alpha.getbootstrap.com/favicon.ico\">

    <title>";
        // line 10
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\">
    <link href=\"http://v4-alpha.getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
    ";
        // line 15
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <style>
        .demo {
        border-radius: 0px;
        background: linear-gradient( rgba(20,20,20, .5), rgba(20,20,20, .5)), url('";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/background.jpg"), "html", null, true);
        echo "');
        background-repeat: no-repeat;
        background-position: center;
        color: white;
        }
        .demostats { color: white; } .demotitle { color: yellow;} .headshot { padding-right: 5px }
    </style>
    <!-- Custom styles for this template -->
    <link href=\"http://v4-alpha.getbootstrap.com/examples/album/album.css\" rel=\"stylesheet\">
</head>

<body>

<div class=\"collapse bg-inverse\" id=\"navbarHeader\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-8 py-4\">
                <img src=\"holder.js/8px55/thumb\" class=\"rounded float-left headshot\" alt=\"Headshot\">
                <h4 class=\"text-white\">About the Fadex Trading Group</h4>
                <p class=\"text-muted\">Trade multiple markets from a single account, on a Mac, PC, or mobile device. Trade on a secure, US-based, regulated exchange. Trade with low cost, no broker commissions, and guaranteed limited risk.</p>
            </div>
            <div class=\"col-sm-4 py-4\">
                <h4 class=\"text-white\">Contact</h4>
                <ul class=\"list-unstyled\">
                    <li><a href=\"#\" class=\"text-white\">Follow on Twitter</a></li>
                    <li><a href=\"#\" class=\"text-white\">Like on Facebook</a></li>
                    <li><a href=\"#\" class=\"text-white\">Email me</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class=\"navbar navbar-inverse bg-inverse\">
    <div class=\"container d-flex justify-content-between\">
        <a href=\"#\" class=\"navbar-brand\">FADEX</a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarHeader\" aria-controls=\"navbarHeader\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>
    </div>
</div>
";
        // line 59
        $this->displayBlock('body', $context, $blocks);
        // line 60
        echo "<footer class=\"text-muted\">
    <div class=\"container\">
        <p class=\"float-right\">
            <a href=\"#\">Back to top</a>
        </p>
        <p>Fadex Trading Group is &copy 2018; Register for news, signals and more!</p>
        <p>New to Binary Options Trading? <a href=\"#\">have an adviser call you in the next 15 minutes</a> or read our <a href=\"#\">getting started guide</a>.</p>
    </div>
</footer>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src=\"https://code.jquery.com/jquery-3.1.1.slim.min.js\" integrity=\"sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n\" crossorigin=\"anonymous\"></script>
<script>window.jQuery || document.write('<script src=\"../../assets/js/vendor/jquery.min.js\"><\\/script>')</script>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js\" integrity=\"sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb\" crossorigin=\"anonymous\"></script>
<script src=\"http://v4-alpha.getbootstrap.com/assets/js/vendor/holder.min.js\"></script>
<script>
    \$(function () {
        Holder.addTheme(\"thumb\", { background: \"#55595c\", foreground: \"#eceeef\", text: \"Thumbnail\" });
    });
</script>
<script src=\"http://v4-alpha.getbootstrap.com/dist/js/bootstrap.min.js\"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src=\"http://v4-alpha.getbootstrap.com/assets/js/ie10-viewport-bug-workaround.js\"></script>
<script type=\"text/javascript\" src=\"https://www.gstatic.com/charts/loader.js\"></script>
<script type=\"text/javascript\">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['Mon', 20, 28, 38, 45],
            ['Tue', 31, 38, 55, 66],
            ['Wed', 50, 55, 77, 80],
            ['Thu', 77, 77, 66, 50],
            ['Fri', 68, 66, 22, 15]
            // Treat first row as data as well.
        ], true);
        var options = {
            legend:'none'
        };
        var a = new google.visualization.CandlestickChart(document.getElementById('chart_diva'));a.draw(data, options);
        var b = new google.visualization.CandlestickChart(document.getElementById('chart_divb'));b.draw(data, options);
        var c = new google.visualization.CandlestickChart(document.getElementById('chart_divc'));c.draw(data, options);
    }
</script>

";
        // line 107
        $this->displayBlock('javascripts', $context, $blocks);
        // line 108
        echo "</body>
</html>

";
        
        $__internal_37681746a841c85517b221b140e12c55d3b168ccc541320bf82efdc4fea282c4->leave($__internal_37681746a841c85517b221b140e12c55d3b168ccc541320bf82efdc4fea282c4_prof);

        
        $__internal_f2475e44ec6a9bbba507dea6407042987138c83629586ae1efef90ba84c9ecba->leave($__internal_f2475e44ec6a9bbba507dea6407042987138c83629586ae1efef90ba84c9ecba_prof);

    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        $__internal_313dade0cca7f22204f85bb7bcf0be4172b69517aebf2bbf837fce06615766d0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_313dade0cca7f22204f85bb7bcf0be4172b69517aebf2bbf837fce06615766d0->enter($__internal_313dade0cca7f22204f85bb7bcf0be4172b69517aebf2bbf837fce06615766d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_7560756aa33cf79fe8e0b874de15f58b91214b4bd1775b464cb89c07e5129a9b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7560756aa33cf79fe8e0b874de15f58b91214b4bd1775b464cb89c07e5129a9b->enter($__internal_7560756aa33cf79fe8e0b874de15f58b91214b4bd1775b464cb89c07e5129a9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "php-fadex-post-signals";
        
        $__internal_7560756aa33cf79fe8e0b874de15f58b91214b4bd1775b464cb89c07e5129a9b->leave($__internal_7560756aa33cf79fe8e0b874de15f58b91214b4bd1775b464cb89c07e5129a9b_prof);

        
        $__internal_313dade0cca7f22204f85bb7bcf0be4172b69517aebf2bbf837fce06615766d0->leave($__internal_313dade0cca7f22204f85bb7bcf0be4172b69517aebf2bbf837fce06615766d0_prof);

    }

    // line 15
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_515b476b379facd0856724a13b1220fd156b34095e81766937f4071fbd658b03 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_515b476b379facd0856724a13b1220fd156b34095e81766937f4071fbd658b03->enter($__internal_515b476b379facd0856724a13b1220fd156b34095e81766937f4071fbd658b03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_ca0e846c239699f5b00a08e5e137dfc001eefedfa1353605a0816bda65515c08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca0e846c239699f5b00a08e5e137dfc001eefedfa1353605a0816bda65515c08->enter($__internal_ca0e846c239699f5b00a08e5e137dfc001eefedfa1353605a0816bda65515c08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_ca0e846c239699f5b00a08e5e137dfc001eefedfa1353605a0816bda65515c08->leave($__internal_ca0e846c239699f5b00a08e5e137dfc001eefedfa1353605a0816bda65515c08_prof);

        
        $__internal_515b476b379facd0856724a13b1220fd156b34095e81766937f4071fbd658b03->leave($__internal_515b476b379facd0856724a13b1220fd156b34095e81766937f4071fbd658b03_prof);

    }

    // line 59
    public function block_body($context, array $blocks = array())
    {
        $__internal_4c80157611118cecd7162121622dccf4584ca387f987874fc45aa09da6004ae1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4c80157611118cecd7162121622dccf4584ca387f987874fc45aa09da6004ae1->enter($__internal_4c80157611118cecd7162121622dccf4584ca387f987874fc45aa09da6004ae1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_708405725240200b358aefa2d4604e6dfdfe68a52c1fac3d1a62cd47b4870b77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_708405725240200b358aefa2d4604e6dfdfe68a52c1fac3d1a62cd47b4870b77->enter($__internal_708405725240200b358aefa2d4604e6dfdfe68a52c1fac3d1a62cd47b4870b77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_708405725240200b358aefa2d4604e6dfdfe68a52c1fac3d1a62cd47b4870b77->leave($__internal_708405725240200b358aefa2d4604e6dfdfe68a52c1fac3d1a62cd47b4870b77_prof);

        
        $__internal_4c80157611118cecd7162121622dccf4584ca387f987874fc45aa09da6004ae1->leave($__internal_4c80157611118cecd7162121622dccf4584ca387f987874fc45aa09da6004ae1_prof);

    }

    // line 107
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4b5716f037af40206cadee983c3e7796ba4556a2628e19f56b198b5bd24e335b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4b5716f037af40206cadee983c3e7796ba4556a2628e19f56b198b5bd24e335b->enter($__internal_4b5716f037af40206cadee983c3e7796ba4556a2628e19f56b198b5bd24e335b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_32edf6f02a0183e67504d5ade7a81a041dd76827827d8b8c5602eef7b128bd76 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_32edf6f02a0183e67504d5ade7a81a041dd76827827d8b8c5602eef7b128bd76->enter($__internal_32edf6f02a0183e67504d5ade7a81a041dd76827827d8b8c5602eef7b128bd76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_32edf6f02a0183e67504d5ade7a81a041dd76827827d8b8c5602eef7b128bd76->leave($__internal_32edf6f02a0183e67504d5ade7a81a041dd76827827d8b8c5602eef7b128bd76_prof);

        
        $__internal_4b5716f037af40206cadee983c3e7796ba4556a2628e19f56b198b5bd24e335b->leave($__internal_4b5716f037af40206cadee983c3e7796ba4556a2628e19f56b198b5bd24e335b_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  216 => 107,  199 => 59,  182 => 15,  164 => 10,  151 => 108,  149 => 107,  100 => 60,  98 => 59,  55 => 19,  50 => 16,  48 => 15,  40 => 10,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"http://v4-alpha.getbootstrap.com/favicon.ico\">

    <title>{% block title %}php-fadex-post-signals{% endblock %}</title>

    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\">
    <link href=\"http://v4-alpha.getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
    {% block stylesheets %}{% endblock %}
    <style>
        .demo {
        border-radius: 0px;
        background: linear-gradient( rgba(20,20,20, .5), rgba(20,20,20, .5)), url('{{  asset('img/background.jpg') }}');
        background-repeat: no-repeat;
        background-position: center;
        color: white;
        }
        .demostats { color: white; } .demotitle { color: yellow;} .headshot { padding-right: 5px }
    </style>
    <!-- Custom styles for this template -->
    <link href=\"http://v4-alpha.getbootstrap.com/examples/album/album.css\" rel=\"stylesheet\">
</head>

<body>

<div class=\"collapse bg-inverse\" id=\"navbarHeader\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-8 py-4\">
                <img src=\"holder.js/8px55/thumb\" class=\"rounded float-left headshot\" alt=\"Headshot\">
                <h4 class=\"text-white\">About the Fadex Trading Group</h4>
                <p class=\"text-muted\">Trade multiple markets from a single account, on a Mac, PC, or mobile device. Trade on a secure, US-based, regulated exchange. Trade with low cost, no broker commissions, and guaranteed limited risk.</p>
            </div>
            <div class=\"col-sm-4 py-4\">
                <h4 class=\"text-white\">Contact</h4>
                <ul class=\"list-unstyled\">
                    <li><a href=\"#\" class=\"text-white\">Follow on Twitter</a></li>
                    <li><a href=\"#\" class=\"text-white\">Like on Facebook</a></li>
                    <li><a href=\"#\" class=\"text-white\">Email me</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class=\"navbar navbar-inverse bg-inverse\">
    <div class=\"container d-flex justify-content-between\">
        <a href=\"#\" class=\"navbar-brand\">FADEX</a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarHeader\" aria-controls=\"navbarHeader\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>
    </div>
</div>
{% block body %}{% endblock %}
<footer class=\"text-muted\">
    <div class=\"container\">
        <p class=\"float-right\">
            <a href=\"#\">Back to top</a>
        </p>
        <p>Fadex Trading Group is &copy 2018; Register for news, signals and more!</p>
        <p>New to Binary Options Trading? <a href=\"#\">have an adviser call you in the next 15 minutes</a> or read our <a href=\"#\">getting started guide</a>.</p>
    </div>
</footer>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src=\"https://code.jquery.com/jquery-3.1.1.slim.min.js\" integrity=\"sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n\" crossorigin=\"anonymous\"></script>
<script>window.jQuery || document.write('<script src=\"../../assets/js/vendor/jquery.min.js\"><\\/script>')</script>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js\" integrity=\"sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb\" crossorigin=\"anonymous\"></script>
<script src=\"http://v4-alpha.getbootstrap.com/assets/js/vendor/holder.min.js\"></script>
<script>
    \$(function () {
        Holder.addTheme(\"thumb\", { background: \"#55595c\", foreground: \"#eceeef\", text: \"Thumbnail\" });
    });
</script>
<script src=\"http://v4-alpha.getbootstrap.com/dist/js/bootstrap.min.js\"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src=\"http://v4-alpha.getbootstrap.com/assets/js/ie10-viewport-bug-workaround.js\"></script>
<script type=\"text/javascript\" src=\"https://www.gstatic.com/charts/loader.js\"></script>
<script type=\"text/javascript\">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['Mon', 20, 28, 38, 45],
            ['Tue', 31, 38, 55, 66],
            ['Wed', 50, 55, 77, 80],
            ['Thu', 77, 77, 66, 50],
            ['Fri', 68, 66, 22, 15]
            // Treat first row as data as well.
        ], true);
        var options = {
            legend:'none'
        };
        var a = new google.visualization.CandlestickChart(document.getElementById('chart_diva'));a.draw(data, options);
        var b = new google.visualization.CandlestickChart(document.getElementById('chart_divb'));b.draw(data, options);
        var c = new google.visualization.CandlestickChart(document.getElementById('chart_divc'));c.draw(data, options);
    }
</script>

{% block javascripts %}{% endblock %}
</body>
</html>

", "base.html.twig", "/var/www/html/project_fadex/app/Resources/views/base.html.twig");
    }
}
