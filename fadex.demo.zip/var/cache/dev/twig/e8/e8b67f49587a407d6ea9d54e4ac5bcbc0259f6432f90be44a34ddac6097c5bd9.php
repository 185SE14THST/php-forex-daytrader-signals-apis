<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_04b0d5b68b2e7cad0dd94f8a266e92ef18dc421a23faaba9704df6a5f3ed9acd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4ad3c05a399b614f720162ae424774fa9c71b12c22fc0ba6ac827d5c3f4bd2c2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4ad3c05a399b614f720162ae424774fa9c71b12c22fc0ba6ac827d5c3f4bd2c2->enter($__internal_4ad3c05a399b614f720162ae424774fa9c71b12c22fc0ba6ac827d5c3f4bd2c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $__internal_e5454f054bee88015307ab0a44fb5dc3a676c150d493ac18251f9411bdf1ba02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5454f054bee88015307ab0a44fb5dc3a676c150d493ac18251f9411bdf1ba02->enter($__internal_e5454f054bee88015307ab0a44fb5dc3a676c150d493ac18251f9411bdf1ba02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4ad3c05a399b614f720162ae424774fa9c71b12c22fc0ba6ac827d5c3f4bd2c2->leave($__internal_4ad3c05a399b614f720162ae424774fa9c71b12c22fc0ba6ac827d5c3f4bd2c2_prof);

        
        $__internal_e5454f054bee88015307ab0a44fb5dc3a676c150d493ac18251f9411bdf1ba02->leave($__internal_e5454f054bee88015307ab0a44fb5dc3a676c150d493ac18251f9411bdf1ba02_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_f812477854f7322335e582106a3fd5ae4503ea6619bb186199b2aa97e573b0fa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f812477854f7322335e582106a3fd5ae4503ea6619bb186199b2aa97e573b0fa->enter($__internal_f812477854f7322335e582106a3fd5ae4503ea6619bb186199b2aa97e573b0fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_3c6b301d5edb6545ebaaca9ab909784fe091543cc01a7ca1162c4b8aadf2af9b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c6b301d5edb6545ebaaca9ab909784fe091543cc01a7ca1162c4b8aadf2af9b->enter($__internal_3c6b301d5edb6545ebaaca9ab909784fe091543cc01a7ca1162c4b8aadf2af9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
";
        
        $__internal_3c6b301d5edb6545ebaaca9ab909784fe091543cc01a7ca1162c4b8aadf2af9b->leave($__internal_3c6b301d5edb6545ebaaca9ab909784fe091543cc01a7ca1162c4b8aadf2af9b_prof);

        
        $__internal_f812477854f7322335e582106a3fd5ae4503ea6619bb186199b2aa97e573b0fa->leave($__internal_f812477854f7322335e582106a3fd5ae4503ea6619bb186199b2aa97e573b0fa_prof);

    }

    // line 136
    public function block_title($context, array $blocks = array())
    {
        $__internal_a98acf45bc4a97e18993acf454139b5381be24eaeff5378d27386ea9493027b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a98acf45bc4a97e18993acf454139b5381be24eaeff5378d27386ea9493027b4->enter($__internal_a98acf45bc4a97e18993acf454139b5381be24eaeff5378d27386ea9493027b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5887b3714691f509237c8a3ccc281ebe9e5a0694d6a4ab9d544a39ea7969e22d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5887b3714691f509237c8a3ccc281ebe9e5a0694d6a4ab9d544a39ea7969e22d->enter($__internal_5887b3714691f509237c8a3ccc281ebe9e5a0694d6a4ab9d544a39ea7969e22d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 137
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_5887b3714691f509237c8a3ccc281ebe9e5a0694d6a4ab9d544a39ea7969e22d->leave($__internal_5887b3714691f509237c8a3ccc281ebe9e5a0694d6a4ab9d544a39ea7969e22d_prof);

        
        $__internal_a98acf45bc4a97e18993acf454139b5381be24eaeff5378d27386ea9493027b4->leave($__internal_a98acf45bc4a97e18993acf454139b5381be24eaeff5378d27386ea9493027b4_prof);

    }

    // line 140
    public function block_body($context, array $blocks = array())
    {
        $__internal_78e6e065653a54edaf3ba373041d2cf8753225849001b77126fe9651fe8a6bf4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78e6e065653a54edaf3ba373041d2cf8753225849001b77126fe9651fe8a6bf4->enter($__internal_78e6e065653a54edaf3ba373041d2cf8753225849001b77126fe9651fe8a6bf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_50fcd5a839624fb13d41613f603751d7484f3b84ca832b4ee304805ee3b920a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50fcd5a839624fb13d41613f603751d7484f3b84ca832b4ee304805ee3b920a5->enter($__internal_50fcd5a839624fb13d41613f603751d7484f3b84ca832b4ee304805ee3b920a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 141
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 141)->display($context);
        
        $__internal_50fcd5a839624fb13d41613f603751d7484f3b84ca832b4ee304805ee3b920a5->leave($__internal_50fcd5a839624fb13d41613f603751d7484f3b84ca832b4ee304805ee3b920a5_prof);

        
        $__internal_78e6e065653a54edaf3ba373041d2cf8753225849001b77126fe9651fe8a6bf4->leave($__internal_78e6e065653a54edaf3ba373041d2cf8753225849001b77126fe9651fe8a6bf4_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 141,  217 => 140,  200 => 137,  191 => 136,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "/var/www/html/project_fadex/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception_full.html.twig");
    }
}
