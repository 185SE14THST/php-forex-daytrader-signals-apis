<?php

/* base.html.twig */
class __TwigTemplate_ecb3622156435dcef755b54ddd8e4732d0aa1bb06c91b31273e3d3ad684eea6d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a231b772d3c4e108b88885fc3dec5c5803d121963912c51b6ce2b4d0b379c31 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9a231b772d3c4e108b88885fc3dec5c5803d121963912c51b6ce2b4d0b379c31->enter($__internal_9a231b772d3c4e108b88885fc3dec5c5803d121963912c51b6ce2b4d0b379c31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_3ecb6068085b57fea2defe82e1d2e14ffefcb1da01610211c6df02637e2ff46e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3ecb6068085b57fea2defe82e1d2e14ffefcb1da01610211c6df02637e2ff46e->enter($__internal_3ecb6068085b57fea2defe82e1d2e14ffefcb1da01610211c6df02637e2ff46e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"http://v4-alpha.getbootstrap.com/favicon.ico\">

    <title>";
        // line 10
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <!-- Bootstrap core CSS -->
    <link href=\"http://v4-alpha.getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
    ";
        // line 14
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 15
        echo "    <style>
        .demo {
        border-radius: 0px;
        background: linear-gradient( rgba(20,20,20, .5), rgba(20,20,20, .5)), url('img/background.jpg');
        background-repeat: no-repeat;
        background-position: center;
        color: lightgrey;
        }
    </style>
    <!-- Custom styles for this template -->
    <link href=\"http://v4-alpha.getbootstrap.com/examples/album/album.css\" rel=\"stylesheet\">
</head>

<body>

<div class=\"collapse bg-inverse\" id=\"navbarHeader\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-8 py-4\">
                <h4 class=\"text-white\">About</h4>
                <p class=\"text-muted\">Add some information about the album below, the author, or any other background context. Make it a few sentences long so folks can pick up some informative tidbits. Then, link them off to some social networking sites or contact information.</p>
            </div>
            <div class=\"col-sm-4 py-4\">
                <h4 class=\"text-white\">Contact</h4>
                <ul class=\"list-unstyled\">
                    <li><a href=\"#\" class=\"text-white\">Follow on Twitter</a></li>
                    <li><a href=\"#\" class=\"text-white\">Like on Facebook</a></li>
                    <li><a href=\"#\" class=\"text-white\">Email me</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class=\"navbar navbar-inverse bg-inverse\">
    <div class=\"container d-flex justify-content-between\">
        <a href=\"#\" class=\"navbar-brand\">FADEX</a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarHeader\" aria-controls=\"navbarHeader\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>
    </div>
</div>
";
        // line 56
        $this->displayBlock('body', $context, $blocks);
        // line 57
        echo "<footer class=\"text-muted\">
    <div class=\"container\">
        <p class=\"float-right\">
            <a href=\"#\">Back to top</a>
        </p>
        <p>Album example is &copy; Bootstrap, but please download and customize it for yourself!</p>
        <p>New to Bootstrap? <a href=\"../../\">Visit the homepage</a> or read our <a href=\"../../getting-started/\">getting started guide</a>.</p>
    </div>
</footer>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src=\"https://code.jquery.com/jquery-3.1.1.slim.min.js\" integrity=\"sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n\" crossorigin=\"anonymous\"></script>
<script>window.jQuery || document.write('<script src=\"../../assets/js/vendor/jquery.min.js\"><\\/script>')</script>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js\" integrity=\"sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb\" crossorigin=\"anonymous\"></script>
<script src=\"http://v4-alpha.getbootstrap.com/assets/js/vendor/holder.min.js\"></script>
<script>
    \$(function () {
        Holder.addTheme(\"thumb\", { background: \"#55595c\", foreground: \"#eceeef\", text: \"Thumbnail\" });
    });
</script>
<script src=\"http://v4-alpha.getbootstrap.com/dist/js/bootstrap.min.js\"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src=\"http://v4-alpha.getbootstrap.com/assets/js/ie10-viewport-bug-workaround.js\"></script>
";
        // line 82
        $this->displayBlock('javascripts', $context, $blocks);
        // line 83
        echo "</body>
</html>

";
        
        $__internal_9a231b772d3c4e108b88885fc3dec5c5803d121963912c51b6ce2b4d0b379c31->leave($__internal_9a231b772d3c4e108b88885fc3dec5c5803d121963912c51b6ce2b4d0b379c31_prof);

        
        $__internal_3ecb6068085b57fea2defe82e1d2e14ffefcb1da01610211c6df02637e2ff46e->leave($__internal_3ecb6068085b57fea2defe82e1d2e14ffefcb1da01610211c6df02637e2ff46e_prof);

    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        $__internal_ce1367a7081c2ce23a6573691997628290b4760ec65999bb4e2c21e8206f4e87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce1367a7081c2ce23a6573691997628290b4760ec65999bb4e2c21e8206f4e87->enter($__internal_ce1367a7081c2ce23a6573691997628290b4760ec65999bb4e2c21e8206f4e87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2bec11316c37f3ecc14bdd6b172c2869f77f822789c4e666176cb0b00eb23453 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2bec11316c37f3ecc14bdd6b172c2869f77f822789c4e666176cb0b00eb23453->enter($__internal_2bec11316c37f3ecc14bdd6b172c2869f77f822789c4e666176cb0b00eb23453_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "php-fadex-post-signals";
        
        $__internal_2bec11316c37f3ecc14bdd6b172c2869f77f822789c4e666176cb0b00eb23453->leave($__internal_2bec11316c37f3ecc14bdd6b172c2869f77f822789c4e666176cb0b00eb23453_prof);

        
        $__internal_ce1367a7081c2ce23a6573691997628290b4760ec65999bb4e2c21e8206f4e87->leave($__internal_ce1367a7081c2ce23a6573691997628290b4760ec65999bb4e2c21e8206f4e87_prof);

    }

    // line 14
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_1b0cf4274997b5e89b5293962e2da9fb257b828bc990e041800ad150e77f98c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b0cf4274997b5e89b5293962e2da9fb257b828bc990e041800ad150e77f98c7->enter($__internal_1b0cf4274997b5e89b5293962e2da9fb257b828bc990e041800ad150e77f98c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_8d535ae31d8440dea84f0153e4c1680aa4209b13c6bd243c7761ee3de4f3de0a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d535ae31d8440dea84f0153e4c1680aa4209b13c6bd243c7761ee3de4f3de0a->enter($__internal_8d535ae31d8440dea84f0153e4c1680aa4209b13c6bd243c7761ee3de4f3de0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_8d535ae31d8440dea84f0153e4c1680aa4209b13c6bd243c7761ee3de4f3de0a->leave($__internal_8d535ae31d8440dea84f0153e4c1680aa4209b13c6bd243c7761ee3de4f3de0a_prof);

        
        $__internal_1b0cf4274997b5e89b5293962e2da9fb257b828bc990e041800ad150e77f98c7->leave($__internal_1b0cf4274997b5e89b5293962e2da9fb257b828bc990e041800ad150e77f98c7_prof);

    }

    // line 56
    public function block_body($context, array $blocks = array())
    {
        $__internal_e7b5839e926aa5953cc5b2f9c4a123d0bbbb70ce196c80ce078e0d05d0db3e2a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7b5839e926aa5953cc5b2f9c4a123d0bbbb70ce196c80ce078e0d05d0db3e2a->enter($__internal_e7b5839e926aa5953cc5b2f9c4a123d0bbbb70ce196c80ce078e0d05d0db3e2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d6c49cd207f5b381a0086bb6c3f2ee36cf402f0b8d1fecfd5e34afc158efe6d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6c49cd207f5b381a0086bb6c3f2ee36cf402f0b8d1fecfd5e34afc158efe6d9->enter($__internal_d6c49cd207f5b381a0086bb6c3f2ee36cf402f0b8d1fecfd5e34afc158efe6d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_d6c49cd207f5b381a0086bb6c3f2ee36cf402f0b8d1fecfd5e34afc158efe6d9->leave($__internal_d6c49cd207f5b381a0086bb6c3f2ee36cf402f0b8d1fecfd5e34afc158efe6d9_prof);

        
        $__internal_e7b5839e926aa5953cc5b2f9c4a123d0bbbb70ce196c80ce078e0d05d0db3e2a->leave($__internal_e7b5839e926aa5953cc5b2f9c4a123d0bbbb70ce196c80ce078e0d05d0db3e2a_prof);

    }

    // line 82
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_bc53c2cf1737fd21bbb6320791d5a9b05bd4f8fd6f355244f24f6bdf00f3f2c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc53c2cf1737fd21bbb6320791d5a9b05bd4f8fd6f355244f24f6bdf00f3f2c7->enter($__internal_bc53c2cf1737fd21bbb6320791d5a9b05bd4f8fd6f355244f24f6bdf00f3f2c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_0575081ad08337cc6385261766727ce170aba2f75ea994ada5bcf9b5e109bdf5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0575081ad08337cc6385261766727ce170aba2f75ea994ada5bcf9b5e109bdf5->enter($__internal_0575081ad08337cc6385261766727ce170aba2f75ea994ada5bcf9b5e109bdf5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_0575081ad08337cc6385261766727ce170aba2f75ea994ada5bcf9b5e109bdf5->leave($__internal_0575081ad08337cc6385261766727ce170aba2f75ea994ada5bcf9b5e109bdf5_prof);

        
        $__internal_bc53c2cf1737fd21bbb6320791d5a9b05bd4f8fd6f355244f24f6bdf00f3f2c7->leave($__internal_bc53c2cf1737fd21bbb6320791d5a9b05bd4f8fd6f355244f24f6bdf00f3f2c7_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  188 => 82,  171 => 56,  154 => 14,  136 => 10,  123 => 83,  121 => 82,  94 => 57,  92 => 56,  49 => 15,  47 => 14,  40 => 10,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"http://v4-alpha.getbootstrap.com/favicon.ico\">

    <title>{% block title %}php-fadex-post-signals{% endblock %}</title>

    <!-- Bootstrap core CSS -->
    <link href=\"http://v4-alpha.getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
    {% block stylesheets %}{% endblock %}
    <style>
        .demo {
        border-radius: 0px;
        background: linear-gradient( rgba(20,20,20, .5), rgba(20,20,20, .5)), url('img/background.jpg');
        background-repeat: no-repeat;
        background-position: center;
        color: lightgrey;
        }
    </style>
    <!-- Custom styles for this template -->
    <link href=\"http://v4-alpha.getbootstrap.com/examples/album/album.css\" rel=\"stylesheet\">
</head>

<body>

<div class=\"collapse bg-inverse\" id=\"navbarHeader\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-8 py-4\">
                <h4 class=\"text-white\">About</h4>
                <p class=\"text-muted\">Add some information about the album below, the author, or any other background context. Make it a few sentences long so folks can pick up some informative tidbits. Then, link them off to some social networking sites or contact information.</p>
            </div>
            <div class=\"col-sm-4 py-4\">
                <h4 class=\"text-white\">Contact</h4>
                <ul class=\"list-unstyled\">
                    <li><a href=\"#\" class=\"text-white\">Follow on Twitter</a></li>
                    <li><a href=\"#\" class=\"text-white\">Like on Facebook</a></li>
                    <li><a href=\"#\" class=\"text-white\">Email me</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class=\"navbar navbar-inverse bg-inverse\">
    <div class=\"container d-flex justify-content-between\">
        <a href=\"#\" class=\"navbar-brand\">FADEX</a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarHeader\" aria-controls=\"navbarHeader\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>
    </div>
</div>
{% block body %}{% endblock %}
<footer class=\"text-muted\">
    <div class=\"container\">
        <p class=\"float-right\">
            <a href=\"#\">Back to top</a>
        </p>
        <p>Album example is &copy; Bootstrap, but please download and customize it for yourself!</p>
        <p>New to Bootstrap? <a href=\"../../\">Visit the homepage</a> or read our <a href=\"../../getting-started/\">getting started guide</a>.</p>
    </div>
</footer>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src=\"https://code.jquery.com/jquery-3.1.1.slim.min.js\" integrity=\"sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n\" crossorigin=\"anonymous\"></script>
<script>window.jQuery || document.write('<script src=\"../../assets/js/vendor/jquery.min.js\"><\\/script>')</script>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js\" integrity=\"sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb\" crossorigin=\"anonymous\"></script>
<script src=\"http://v4-alpha.getbootstrap.com/assets/js/vendor/holder.min.js\"></script>
<script>
    \$(function () {
        Holder.addTheme(\"thumb\", { background: \"#55595c\", foreground: \"#eceeef\", text: \"Thumbnail\" });
    });
</script>
<script src=\"http://v4-alpha.getbootstrap.com/dist/js/bootstrap.min.js\"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src=\"http://v4-alpha.getbootstrap.com/assets/js/ie10-viewport-bug-workaround.js\"></script>
{% block javascripts %}{% endblock %}
</body>
</html>

", "base.html.twig", "/var/www/html/project_fadex/app/Resources/views/base.html.twig");
    }
}
