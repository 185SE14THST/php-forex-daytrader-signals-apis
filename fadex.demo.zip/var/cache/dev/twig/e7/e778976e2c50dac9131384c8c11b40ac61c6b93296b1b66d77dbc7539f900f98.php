<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_cfb74f884cf203f6906e636b869738007974dae0b441ad14c66ced0c02c216cb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_99a7830c285b5830b74fd0a2c6a989d473fc2e1e5a0321411d58a9aab0fd0cdd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99a7830c285b5830b74fd0a2c6a989d473fc2e1e5a0321411d58a9aab0fd0cdd->enter($__internal_99a7830c285b5830b74fd0a2c6a989d473fc2e1e5a0321411d58a9aab0fd0cdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_a9e820b08b8dc92d4fe61966e7938b1a7b7bce8f634c2109501e69784a764d88 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a9e820b08b8dc92d4fe61966e7938b1a7b7bce8f634c2109501e69784a764d88->enter($__internal_a9e820b08b8dc92d4fe61966e7938b1a7b7bce8f634c2109501e69784a764d88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_99a7830c285b5830b74fd0a2c6a989d473fc2e1e5a0321411d58a9aab0fd0cdd->leave($__internal_99a7830c285b5830b74fd0a2c6a989d473fc2e1e5a0321411d58a9aab0fd0cdd_prof);

        
        $__internal_a9e820b08b8dc92d4fe61966e7938b1a7b7bce8f634c2109501e69784a764d88->leave($__internal_a9e820b08b8dc92d4fe61966e7938b1a7b7bce8f634c2109501e69784a764d88_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_ab77a497b2a61a6145858d2ad3f4598cb5cd97f95d9c05387dd0337a46eadd53 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ab77a497b2a61a6145858d2ad3f4598cb5cd97f95d9c05387dd0337a46eadd53->enter($__internal_ab77a497b2a61a6145858d2ad3f4598cb5cd97f95d9c05387dd0337a46eadd53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_7f2b43f0d5784e0adb2ca6685abf1af19023df2334666baee6b7f55c0609ee79 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f2b43f0d5784e0adb2ca6685abf1af19023df2334666baee6b7f55c0609ee79->enter($__internal_7f2b43f0d5784e0adb2ca6685abf1af19023df2334666baee6b7f55c0609ee79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_7f2b43f0d5784e0adb2ca6685abf1af19023df2334666baee6b7f55c0609ee79->leave($__internal_7f2b43f0d5784e0adb2ca6685abf1af19023df2334666baee6b7f55c0609ee79_prof);

        
        $__internal_ab77a497b2a61a6145858d2ad3f4598cb5cd97f95d9c05387dd0337a46eadd53->leave($__internal_ab77a497b2a61a6145858d2ad3f4598cb5cd97f95d9c05387dd0337a46eadd53_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_71d5d8a5648ec0329648a36b6496eeeeb7dc91d8669795b767100b0908b9fb4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_71d5d8a5648ec0329648a36b6496eeeeb7dc91d8669795b767100b0908b9fb4a->enter($__internal_71d5d8a5648ec0329648a36b6496eeeeb7dc91d8669795b767100b0908b9fb4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_e493070122e4de2df4c819808bb91f81e9f313f79a5ea0b24527b2b570c1621c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e493070122e4de2df4c819808bb91f81e9f313f79a5ea0b24527b2b570c1621c->enter($__internal_e493070122e4de2df4c819808bb91f81e9f313f79a5ea0b24527b2b570c1621c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_e493070122e4de2df4c819808bb91f81e9f313f79a5ea0b24527b2b570c1621c->leave($__internal_e493070122e4de2df4c819808bb91f81e9f313f79a5ea0b24527b2b570c1621c_prof);

        
        $__internal_71d5d8a5648ec0329648a36b6496eeeeb7dc91d8669795b767100b0908b9fb4a->leave($__internal_71d5d8a5648ec0329648a36b6496eeeeb7dc91d8669795b767100b0908b9fb4a_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_11cf8355b9e9d17d5886c5282da6ef292e4dbb2e93f3bc5d71906032a2785f0f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_11cf8355b9e9d17d5886c5282da6ef292e4dbb2e93f3bc5d71906032a2785f0f->enter($__internal_11cf8355b9e9d17d5886c5282da6ef292e4dbb2e93f3bc5d71906032a2785f0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_44aff8852c99a42296f052a67e16ef12d7238b3a1e9bdb4d6817b0906e277cb2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44aff8852c99a42296f052a67e16ef12d7238b3a1e9bdb4d6817b0906e277cb2->enter($__internal_44aff8852c99a42296f052a67e16ef12d7238b3a1e9bdb4d6817b0906e277cb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_44aff8852c99a42296f052a67e16ef12d7238b3a1e9bdb4d6817b0906e277cb2->leave($__internal_44aff8852c99a42296f052a67e16ef12d7238b3a1e9bdb4d6817b0906e277cb2_prof);

        
        $__internal_11cf8355b9e9d17d5886c5282da6ef292e4dbb2e93f3bc5d71906032a2785f0f->leave($__internal_11cf8355b9e9d17d5886c5282da6ef292e4dbb2e93f3bc5d71906032a2785f0f_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/var/www/html/project_fadex/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
