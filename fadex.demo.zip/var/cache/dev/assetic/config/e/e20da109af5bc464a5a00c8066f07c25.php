<?php

// WebProfilerBundle:Profiler:open.html.twig
return array (
);
