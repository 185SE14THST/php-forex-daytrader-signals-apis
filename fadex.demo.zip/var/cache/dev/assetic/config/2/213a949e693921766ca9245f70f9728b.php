<?php

// WebProfilerBundle:Collector:exception.html.twig
return array (
);
