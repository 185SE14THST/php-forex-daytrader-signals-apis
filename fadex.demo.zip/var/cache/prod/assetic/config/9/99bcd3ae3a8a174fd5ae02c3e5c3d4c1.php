<?php

// TwigBundle:Exception:exception.atom.twig
return array (
);
