<?php

// DoctrineBundle:Collector:explain.html.twig
return array (
);
