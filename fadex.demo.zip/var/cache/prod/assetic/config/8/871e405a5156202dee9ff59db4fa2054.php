<?php

// TwigBundle:Exception:exception_full.html.twig
return array (
);
