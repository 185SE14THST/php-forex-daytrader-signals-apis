<?php

/* :default:index.html.twig */
class __TwigTemplate_d77ad4549457b29bdddf1062f0fe75375cb3720ce537565f2872d3814204601d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":default:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    <section class=\"jumbotron text-center demo\">
        <div class=\"container\">
            <h1 class=\"jumbotron-heading demotitle\">Currency Spotlight</h1>
            <p class=\"lead\">Binary options are limited-risk contracts based on a simple yes/no question about the market's price action. Use post signals for deeper insight.</p>
            <div class=\"form-group form-inline row\">
                <div class=\"col-12\">
                    <input class=\"form-control\" type=\"search\" value=\"USDGBP\" id=\"example-search-input\">
                    <a href=\"/\" class=\"btn btn-primary\">Quick Analysis</a>

                </div>
            </div>

            <ul class=\"nav justify-content-center\">
                <li class=\"nav-item\">
                    <a class=\"nav-link active demostats\" href=\"#\"><i class=\"fa fa-line-chart fa-2x\"></i> <h1>";
        // line 18
        echo twig_escape_filter($this->env, ($context["test"] ?? null), "html", null, true);
        echo "</h1></a>
                </li>
            </ul>
            <p>

            </p>
        </div>
    </section>

    <div class=\"album text-muted\">
        <div class=\"container\">

            <div class=\"row\">
                <div class=\"card\">
                    <p><strong>USD/EUR</strong></p>
                    <div id=\"chart_diva\" style=\"width: 356px; height: 280px;\"></div>
                    <p class=\"card-text\"><i class=\"fa fa-newspaper-o fa-1x\"></i>&nbsp;Daily Fx: The British Pound against the US Dollar is one of the oldest currency pairings in the world. The pair is often called 'The Cable', as the first transatlantic communication cable run across the floor of the Atlantic.</p>
                </div>
                <div class=\"card\">
                    <p><strong>USD/GBP</strong></p>
                    <div id=\"chart_divb\" style=\"width: 356px; height: 280px;\"></div>
                    <p class=\"card-text\"><i class=\"fa fa-newspaper-o fa-1x\"></i>&nbsp;Daily Fx: The British Pound against the US Dollar is one of the oldest currency pairings in the world. The pair is often called 'The Cable', as the first transatlantic communication cable run across the floor of the Atlantic.</p>
                </div>
                <div class=\"card\">
                    <p><strong>USD/JPY</strong></p>
                    <div id=\"chart_divc\" style=\"width: 356px; height: 280px;\"></div>
                    <p class=\"card-text\"><i class=\"fa fa-newspaper-o fa-1x\"></i>&nbsp;Daily Fx: The British Pound against the US Dollar is one of the oldest currency pairings in the world. The pair is often called 'The Cable', as the first transatlantic communication cable run across the floor of the Atlantic.</p>
                </div>
            </div>

        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return ":default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  47 => 18,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":default:index.html.twig", "/var/www/html/project_fadex/app/Resources/views/default/index.html.twig");
    }
}
