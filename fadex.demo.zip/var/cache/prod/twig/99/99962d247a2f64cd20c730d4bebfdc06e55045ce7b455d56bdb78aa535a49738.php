<?php

/* ::base.html.twig */
class __TwigTemplate_98e79635c6921c7d7eea1521b26d3943b5f724beab875c4325f279db0050724d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"http://v4-alpha.getbootstrap.com/favicon.ico\">

    <title>";
        // line 10
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\">
    <link href=\"http://v4-alpha.getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
    ";
        // line 15
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <style>
        .demo {
        border-radius: 0px;
        background: linear-gradient( rgba(20,20,20, .5), rgba(20,20,20, .5)), url('";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/background.jpg"), "html", null, true);
        echo "');
        background-repeat: no-repeat;
        background-position: center;
        color: white;
        }
        .demostats { color: white; } .demotitle { color: yellow;} .headshot { padding-right: 5px }
    </style>
    <!-- Custom styles for this template -->
    <link href=\"http://v4-alpha.getbootstrap.com/examples/album/album.css\" rel=\"stylesheet\">
</head>

<body>

<div class=\"collapse bg-inverse\" id=\"navbarHeader\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-8 py-4\">
                <img src=\"holder.js/8px55/thumb\" class=\"rounded float-left headshot\" alt=\"Headshot\">
                <h4 class=\"text-white\">About the Fadex Trading Group</h4>
                <p class=\"text-muted\">Trade multiple markets from a single account, on a Mac, PC, or mobile device. Trade on a secure, US-based, regulated exchange. Trade with low cost, no broker commissions, and guaranteed limited risk.</p>
            </div>
            <div class=\"col-sm-4 py-4\">
                <h4 class=\"text-white\">Contact</h4>
                <ul class=\"list-unstyled\">
                    <li><a href=\"#\" class=\"text-white\">Follow on Twitter</a></li>
                    <li><a href=\"#\" class=\"text-white\">Like on Facebook</a></li>
                    <li><a href=\"#\" class=\"text-white\">Email me</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class=\"navbar navbar-inverse bg-inverse\">
    <div class=\"container d-flex justify-content-between\">
        <a href=\"#\" class=\"navbar-brand\">FADEX</a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarHeader\" aria-controls=\"navbarHeader\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>
    </div>
</div>
";
        // line 59
        $this->displayBlock('body', $context, $blocks);
        // line 60
        echo "<footer class=\"text-muted\">
    <div class=\"container\">
        <p class=\"float-right\">
            <a href=\"#\">Back to top</a>
        </p>
        <p>Fadex Trading Group is &copy 2018; Register for news, signals and more!</p>
        <p>New to Binary Options Trading? <a href=\"#\">have an adviser call you in the next 15 minutes</a> or read our <a href=\"#\">getting started guide</a>.</p>
    </div>
</footer>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src=\"https://code.jquery.com/jquery-3.1.1.slim.min.js\" integrity=\"sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n\" crossorigin=\"anonymous\"></script>
<script>window.jQuery || document.write('<script src=\"../../assets/js/vendor/jquery.min.js\"><\\/script>')</script>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js\" integrity=\"sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb\" crossorigin=\"anonymous\"></script>
<script src=\"http://v4-alpha.getbootstrap.com/assets/js/vendor/holder.min.js\"></script>
<script>
    \$(function () {
        Holder.addTheme(\"thumb\", { background: \"#55595c\", foreground: \"#eceeef\", text: \"Thumbnail\" });
    });
</script>
<script src=\"http://v4-alpha.getbootstrap.com/dist/js/bootstrap.min.js\"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src=\"http://v4-alpha.getbootstrap.com/assets/js/ie10-viewport-bug-workaround.js\"></script>
<script type=\"text/javascript\" src=\"https://www.gstatic.com/charts/loader.js\"></script>
<script type=\"text/javascript\">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['Mon', 20, 28, 38, 45],
            ['Tue', 31, 38, 55, 66],
            ['Wed', 50, 55, 77, 80],
            ['Thu', 77, 77, 66, 50],
            ['Fri', 68, 66, 22, 15]
            // Treat first row as data as well.
        ], true);
        var options = {
            legend:'none'
        };
        var a = new google.visualization.CandlestickChart(document.getElementById('chart_diva'));a.draw(data, options);
        var b = new google.visualization.CandlestickChart(document.getElementById('chart_divb'));b.draw(data, options);
        var c = new google.visualization.CandlestickChart(document.getElementById('chart_divc'));c.draw(data, options);
    }
</script>

";
        // line 107
        $this->displayBlock('javascripts', $context, $blocks);
        // line 108
        echo "</body>
</html>

";
    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        echo "php-fadex-post-signals";
    }

    // line 15
    public function block_stylesheets($context, array $blocks = array())
    {
    }

    // line 59
    public function block_body($context, array $blocks = array())
    {
    }

    // line 107
    public function block_javascripts($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 107,  163 => 59,  158 => 15,  152 => 10,  145 => 108,  143 => 107,  94 => 60,  92 => 59,  49 => 19,  44 => 16,  42 => 15,  34 => 10,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::base.html.twig", "/var/www/html/project_fadex/app/Resources/views/base.html.twig");
    }
}
